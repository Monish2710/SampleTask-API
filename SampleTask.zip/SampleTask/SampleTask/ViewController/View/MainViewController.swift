//
//  ViewController.swift
//  SampleTask
//
//  Created by Pyramidions on 20/03/21.
//

import UIKit
import SDWebImage
import TransitionButton

class ImageLoader
{
    func imageLoad(imgView :UIImageView,url :String)
    {
        imgView.sd_setImage(with: URL(string: url), placeholderImage: UIImage(named: "image1"))
    }
}

class MainViewController: CustomTransitionViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var logoutbtn: UIButton!
    @IBOutlet weak var main: UICollectionView!
    @IBOutlet weak var addcartView: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var mainTableView: UITableView!
    @IBOutlet weak var mainTable: UITableView!
    
    var dataSource = DataViewModel()
    var imgArr = [#imageLiteral(resourceName: "image1"),#imageLiteral(resourceName: "image3"),#imageLiteral(resourceName: "image4"),#imageLiteral(resourceName: "image5"),#imageLiteral(resourceName: "image2")]
    var timer = Timer()
    var counter = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSource.getAllUserData()
        mainTable.delegate = self
        mainTable.dataSource = self
        dataSource.vc = self
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
        mainTable.register(UINib(nibName: "userTableViewCell", bundle: nil), forCellReuseIdentifier: "userTableViewCell")
        mainTable.register(UINib(nibName: "View", bundle: nil), forHeaderFooterViewReuseIdentifier: "View")
        
    }
    
    @IBAction func moveBtnAction(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
   
    @objc func changeImage()
    {
        if counter < imgArr.count {
         let index = IndexPath.init(item: counter, section: 0)
         self.main.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
         pageControl.currentPage = counter
         counter += 1
        } else {
         counter = 0
         let index = IndexPath.init(item: counter, section: 0)
         self.main.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
         pageControl.currentPage = counter
         counter = 1
        }
     }
}

extension MainViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgArr.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = main.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        if let vc = cell.viewWithTag(1) as? UIImageView {
            vc.image = imgArr[indexPath.row]
        }
        return cell
    }
}

extension MainViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = main.frame.size
        return CGSize(width: size.width, height: size.height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.0
    }
}
extension MainViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.arrUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = (mainTable.dequeueReusableCell(withIdentifier: "userTableViewCell", for: indexPath) as? userTableViewCell)!
        cell.productNameLabeel.text = dataSource.arrUsers[indexPath.row].name
        if let imageURL = dataSource.arrUsers[indexPath.row].image {
            ImageLoader().imageLoad(imgView: cell.mainImageView!, url: imageURL)
        }
        
        let price = dataSource.arrUsers[indexPath.row].price ?? ""
        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: price)
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0, attributeString.length))
        cell.pricelbl.attributedText = attributeString
        cell.offerLabel.text = dataSource.arrUsers[indexPath.row].discountAmount
        cell.desclbl.text = dataSource.arrUsers[indexPath.row].datumDescription
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let HomeView = self.storyboard!.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        HomeView.name = dataSource.arrUsers[indexPath.row].name
        HomeView.price = dataSource.arrUsers[indexPath.row].price
        HomeView.descriptions = dataSource.arrUsers[indexPath.row].datumDescription
        HomeView.discountPrice = dataSource.arrUsers[indexPath.row].discountAmount
        HomeView.categories = dataSource.arrUsers[indexPath.row].categories!
        HomeView.image = dataSource.arrUsers[indexPath.row].image
        HomeView.modalTransitionStyle = .flipHorizontal
        self.present(HomeView, animated:true, completion: nil)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 140
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView = mainTable.dequeueReusableHeaderFooterView(withIdentifier: "View") as! View
        headerView.contentView.backgroundColor = .white
        headerView.sortBtn.layer.cornerRadius = 7
               return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 60
    }
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
}
