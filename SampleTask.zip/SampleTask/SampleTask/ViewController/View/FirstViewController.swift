//
//  FirstViewController.swift
//  SampleTask
//
//  Created by Pyramidions on 21/03/21.
//

import UIKit
import AnimatedField
import IQKeyboardManagerSwift
import CoreData
import TransitionButton
import SCLAlertView

class FirstViewController: UIViewController {

    @IBOutlet weak var closeBtn: UIButton!
    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var passwordSignup: AnimatedField!
    @IBOutlet weak var signupName: AnimatedField!
    @IBOutlet weak var signupEmail: AnimatedField!
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var emailID: AnimatedField!
    @IBOutlet weak var passID: AnimatedField!
    @IBOutlet weak var continueBtn: TransitionButton!
    
    var Scroll  = UIScrollView()
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        IQKeyboardManager.shared.enable = true
        // Do any additional setup after loading the view.
        continueBtn.layer.cornerRadius = 15
        signupBtn.layer.cornerRadius = 15

        var format = AnimatedFieldFormat()
        format.titleFont = UIFont(name: "AvenirNext-Regular", size: 14)!
        format.textFont = UIFont(name: "AvenirNext-Regular", size: 16)!
        format.alertColor = .red
        format.alertFieldActive = false
        format.titleAlwaysVisible = true
        format.alertFont = UIFont(name: "AvenirNext-Regular", size: 14)!
        
        emailID.format = format
        emailID.placeholder = "Write your email"
        emailID.dataSource = self
        emailID.delegate = self
        emailID.type = .email
        emailID.tag = 0
        
        passID.format = format
        passID.placeholder = "New password (min 6, max 10)"
        passID.dataSource = self
        passID.delegate = self
        passID.type = .password(6, 10)
        passID.isSecure = true
        passID.showVisibleButton = true
        passID.tag = 1
        
        signupName.format = format
        signupName.placeholder = "Write your username"
        signupName.dataSource = self
        signupName.delegate = self
        signupName.lowercased = true
        signupName.type = .username(4, 10)
        signupName.tag = 2
        
        signupEmail.format = format
        signupEmail.placeholder = "Write your email"
        signupEmail.dataSource = self
        signupEmail.delegate = self
        signupEmail.type = .email
        signupEmail.tag = 3
        
        passwordSignup.format = format
        passwordSignup.placeholder = "New password (min 6, max 10)"
        passwordSignup.dataSource = self
        passwordSignup.delegate = self
        passwordSignup.type = .password(6, 10)
        passwordSignup.isSecure = true
        passwordSignup.showVisibleButton = true
        passwordSignup.tag = 4
    }
    @IBAction func loginBtn(_ button: TransitionButton)
    {
//        button.startAnimation() // 2: Then start the animation when the user tap the button
        let IDAvailable = check(emailIDValue: emailID.text ?? "")
        if IDAvailable
        {
            let HomeView = self.storyboard!.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
            HomeView.modalPresentationStyle = .fullScreen
            HomeView.modalTransitionStyle = .flipHorizontal
            self.present(HomeView, animated: true, completion: nil)
//            let qualityOfServiceClass = DispatchQoS.QoSClass.background
//            let backgroundQueue = DispatchQueue.global(qos: qualityOfServiceClass)
//            backgroundQueue.async(execute: {
//                sleep(3)
//                DispatchQueue.main.async(execute: { () -> Void in
//                    button.stopAnimation(animationStyle: .expand, completion: {
//                        let MainVC = MainViewController()
//                        self.present(MainVC, animated: true, completion: nil)
//                    })
//                })
//            })
        }
        else
        {
            let appearance = SCLAlertView.SCLAppearance(dynamicAnimatorActive: true)
            _ = SCLAlertView(appearance: appearance).showNotice("HucH", subTitle: "Please Signup")
        }
    }
    @objc func firstButton()
    {
        add(emailID: signupEmail.text!, Name: signupName.text!, Password: passwordSignup.text!)
        self.bgView.isHidden = true
          print("First button tapped")
      }
    
    @IBAction func closeAction(_ sender: Any) {
        self.bgView.isHidden = true
    }
    @IBAction func signUpPage(_ sender: Any) {
        self.bgView.isHidden = false
    }
    @IBAction func signupAction(_ sender: Any)
    {
        if signupName.text?.count ?? 0 >= 3 && signupEmail.text?.count ?? 0 >= 3 && passwordSignup.text?.count ?? 0 >= 3
        {
        let appearance = SCLAlertView.SCLAppearance(
            kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
            kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
            kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
            showCloseButton: false,
            dynamicAnimatorActive: true,
            buttonsLayout: .horizontal
        )
        let alert = SCLAlertView(appearance: appearance)
        _ = alert.addButton("Yes", target:self, selector:#selector(self.firstButton))
        _ = alert.addButton("No")
        {
            self.bgView.isHidden = true
        }
        
        let icon = #imageLiteral(resourceName: "h1")
        let color = UIColor.orange
            
        _ = alert.showCustom("HucH", subTitle: "Are you Sure to SignUP", color: color, icon: icon, circleIconImage: icon)
        }
        else
        {
            let appearance = SCLAlertView.SCLAppearance(dynamicAnimatorActive: true)
            _ = SCLAlertView(appearance: appearance).showNotice("HucH", subTitle: "Please Enter All the Values")
        }
    }
    
   
}
extension FirstViewController: AnimatedFieldDelegate {
    
    func animatedFieldDidBeginEditing(_ animatedField: AnimatedField) {
        let offset = animatedField.frame.origin.y + animatedField.frame.size.height - (view.frame.height - 350)
        Scroll.setContentOffset(CGPoint(x: 0, y: offset < 0 ? 0 : offset), animated: true)
    }
    
    func animatedFieldDidEndEditing(_ animatedField: AnimatedField) {
        var offset: CGFloat = 0
        if animatedField.frame.origin.y + animatedField.frame.size.height > Scroll.frame.height {
            offset = animatedField.frame.origin.y + animatedField.frame.size.height - Scroll.frame.height + 10
        }
        Scroll.setContentOffset(CGPoint(x: 0, y: offset), animated: true)
        
        let validEmailUser = emailID.isValid
        continueBtn.isEnabled = validEmailUser
        continueBtn.alpha = validEmailUser ? 1.0 : 0.3
    }

    func animatedFieldDidChange(_ animatedField: AnimatedField) {
        print("text: \(animatedField.text ?? "")")
    }
}

extension FirstViewController: AnimatedFieldDataSource {
    
    func animatedFieldLimit(_ animatedField: AnimatedField) -> Int? {
        switch animatedField.tag {
        case 1: return 30
        case 8: return 30
        default: return nil
        }
    }
    
    func animatedFieldValidationError(_ animatedField: AnimatedField) -> String? {
        if animatedField == emailID {
            return "Email invalid! Please check again ;)"
        }
        return nil
    }
}

extension FirstViewController
{
    func check(emailIDValue : String) -> Bool
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "SampleTask")
        request.returnsObjectsAsFaults = false
        do
        {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject]
            {
                let emailID = data.value(forKey: "emailID") as? String
                if emailID == emailIDValue
                {
                    return true
                }
            }
        }catch
        {
            print("Failed")
        }
        return false
    }
    func add(emailID : String,Name : String, Password : String)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "SampleTask", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        let checkdata = check(emailIDValue: emailID)
        if checkdata == true
        {
            _ = SCLAlertView().showWarning("Sorry", subTitle: "User Already Exist")
        }
        else
        {
            newUser.setValue(emailID, forKey: "emailID")
            newUser.setValue(Password, forKey: "pass")
            newUser.setValue(Name, forKey: "name")
            do {
                try context.save()
            } catch {
                print("Failed saving")
            }
        }
        
    }
}
