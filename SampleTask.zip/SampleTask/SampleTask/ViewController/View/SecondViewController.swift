//
//  SecondViewController.swift
//  Animations
//
//  Created by Pyramidions on 11/02/21.
//

import UIKit
class SecondCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var imageView: UIImageView!
    
  
    override func layoutSubviews()
    {
        super.layoutSubviews()
        imageView.layer.cornerRadius = 10
    }
    func configure(with cellData: CellData) {
        imageView.image = cellData.image
    }
}

struct CellData
{
    let image: UIImage
}


class SecondViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet private(set) var locationImageView: UIImageView!
    @IBOutlet private(set) var locationLabel: UILabel!
    @IBOutlet private(set) var closeButton: UIButton!
    @IBOutlet weak var downloadbutton : UIButton!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var offerprice: UILabel!
    @IBOutlet weak var pricelabel: UILabel!
    
    var name : String?
    var price : String?
    var image : String?
    var descriptions : String?
    var discountPrice :String?
    var categories : [Category]?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        downloadbutton.layer.cornerRadius = 25
        locationImageView.layer.cornerRadius = 20
        self.setupUI()
    }
     func setupUI()
     {
        ImageLoader().imageLoad(imgView: locationImageView, url: image ?? "")
        locationLabel.text = name
        desc.text = descriptions
        let attributeString: NSMutableAttributedString =  NSMutableAttributedString(string: price ?? "")
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0, attributeString.length))
        pricelabel.attributedText = attributeString
        offerprice.text = discountPrice
     }
    
    @IBAction func download(sender:UIButton)
    {
        
    }

    @IBAction func close(_ sender: Any)
    {
        dismiss(animated: true)
    }
    
}

extension SecondViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return DataManager.data.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SecondCollectionViewCell", for: indexPath) as! SecondCollectionViewCell
        cell.configure(with: DataManager.data[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return .init(width: collectionView.frame.width, height: collectionView.frame.height)
    }
}
class DataManager {

    private init() {}

    static let data: [CellData] = [
        .init(image: #imageLiteral(resourceName: "images/1")),
        .init(image: #imageLiteral(resourceName: "images/2")),
        .init(image: #imageLiteral(resourceName: "images/5")),
        .init(image: #imageLiteral(resourceName: "images/6")),
        .init(image: #imageLiteral(resourceName: "images/3")),
        .init(image: #imageLiteral(resourceName: "images/4")),
        .init(image: #imageLiteral(resourceName: "images/7")),
        .init(image: #imageLiteral(resourceName: "images/8"))
    ]

}
