//
//  View.swift
//  Amazon-Ecommerce
//
//  Created by mac on 07/11/20.
//

import UIKit

class View: UITableViewHeaderFooterView
{
    @IBOutlet weak var sortBtn: UIButton!
}
