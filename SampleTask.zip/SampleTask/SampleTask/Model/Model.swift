
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//

import Foundation

// MARK: - ContentModel
struct ContentModel: Codable {
    var code: Int?
    var meta: Meta?
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var id: Int?
    var name, datumDescription: String?
    var image: String?
    var price, discountAmount: String?
    var status: Bool?
    var categories: [Category]?

    enum CodingKeys: String, CodingKey {
        case id, name
        case datumDescription = "description"
        case image, price
        case discountAmount = "discount_amount"
        case status, categories
    }
}

// MARK: - Category
struct Category: Codable {
    var id: Int?
    var name: String?
}

// MARK: - Meta
struct Meta: Codable {
    var pagination: Pagination?
}

// MARK: - Pagination
struct Pagination: Codable {
    var total, pages, page, limit: Int?
}
