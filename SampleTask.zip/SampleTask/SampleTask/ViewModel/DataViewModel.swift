//
//  DataViewModel.swift
//  SampleTask
//
//  Created by Pyramidions on 20/03/21.
//

import Alamofire
import Foundation

class DataViewModel {
    weak var vc: MainViewController?
    var arrUsers = [Datum]()

    func getAllUserData() {
        let url = "https://gorest.co.in/public-api/products"
        AF.request(url).response { response in
            if let data = response.data {
                do {
                    let userResponse = try JSONDecoder().decode(ContentModel.self, from: data)
                    print(userResponse)
                    self.arrUsers.removeAll()
                    self.arrUsers = userResponse.data!
                    print(self.arrUsers)
                    DispatchQueue.main.async {
                        self.vc?.mainTable.reloadData()
                    }
                } catch let err {
                    print(err.localizedDescription)
                }
            }
        }
    }
}
